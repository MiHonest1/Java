import javax.swing.*;
import java.awt.event.*;
import java.io.*;

//Класс окна клиента
public class ClientWindow {

    private JFrame     clientFrame;     //Форма для окна клиента
    private JLabel     clientState;     //Строка о состоянии клиента
    public  SContainer allOurMusic;    //Контейнер форм для хранения списка локальных аудио
    public  SContainer allServerMusic; //Контейнер форм для хранения списка серверных аудио

    // Публичные флаги // Связь с интерфейсом сокетов
    public Boolean     flagStop = false;//Установка флага остановки
    public Boolean     flagAuth = false;//Установка флага подключения
    public Boolean     flagDsAt = false;//Установка флага отключения
    public Boolean     flagDown = false;//Установка флага закачки (скачивания файла)
    public String      downFile = "";   //Имя скачиваемого файла


    ClientWindow()
    {
        //Создание и настройка окна клиента
        clientFrame = new JFrame("Сlient Window");
        clientFrame.setSize(485, 600);
        clientFrame.setLayout(null);
        clientFrame.setVisible(false);
        clientFrame.setResizable(false);

        //Настройка контейнера с локальными аудио
        allOurMusic = new SContainer(clientFrame);
        allOurMusic.SetContainerPosition(0, 0);
        allOurMusic.SetContainerWidth(200);
        allOurMusic.SetContainerName("Local Music");
        allOurMusic.AddNewElement("No Music!");

        //Настройка контейнера с серверными аудио
        allServerMusic = new SContainer(clientFrame);
        allServerMusic.SetContainerPosition(250, 0);
        allServerMusic.SetContainerWidth(200);
        allServerMusic.SetContainerName("Server Music");
        allServerMusic.AddNewElement("No Music!");
        allServerMusic.SetButtonsNames("Connect", "Disconnect");
        allServerMusic.delButton.setVisible(false);
        allServerMusic.addButton.setSize(200, 60);

        //Установка листенеров

        //Реакция на закрытие окна через крестик
        clientFrame.addWindowListener(new WindowListener() {
            public void windowOpened(WindowEvent e) {}
            public void windowClosing(WindowEvent e) {
                flagStop = true;
            }
            public void windowClosed(WindowEvent e) {}
            public void windowIconified(WindowEvent e) {}
            public void windowDeiconified(WindowEvent e) {}
            public void windowActivated(WindowEvent e) {}
            public void windowDeactivated(WindowEvent e) {}
        });

        //Реакция на двойное нажатие по списку аудио с сервера (скачать аудио)
        allServerMusic.table.addMouseListener(new MouseListener() {
            public void mouseClicked(MouseEvent evt) {
                JList mList = (JList) evt.getSource();
                if (evt.getClickCount() == 2) {
                    flagDown = true;
                    downFile = allServerMusic.table.getSelectedValue().toString();
                }
            }

            public void mousePressed(MouseEvent evt) {}
            public void mouseReleased(MouseEvent evt) {}
            public void mouseEntered(MouseEvent evt) {}
            public void mouseExited(MouseEvent evt) {}
        });

        //Реакция на двойное нажатие по списку аудио с локали (Воспроизвести аудио)
        allOurMusic.table.addMouseListener(new MouseListener() {
            public void mouseClicked(MouseEvent evt) {
                JList mList = (JList) evt.getSource();
                if (evt.getClickCount() == 2) {
                    Audio playingAudio = new Audio(allOurMusic.allList);
                    playingAudio.PlayingMp3File("Client/Music/", allOurMusic.table.getSelectedValue().toString());
                }
            }

            public void mousePressed(MouseEvent evt) {}
            public void mouseReleased(MouseEvent evt) {}
            public void mouseEntered(MouseEvent evt) {}
            public void mouseExited(MouseEvent evt) {}
        });





        //Add
        allOurMusic.addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Folder folder = new Folder("Client/Music/");
                folder.CopyFileInDirectory("Client/Music/");
            }
        });

        //Delete
        allOurMusic.delButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Folder folder = new Folder("Client/Music/");
                folder.DeleteFileFromDirectory("Client/Music/");
            }
        });

        //Connect
        allServerMusic.addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                flagAuth = true;
                allServerMusic.addButton.setVisible(false);
                allServerMusic.table.setSize(200, 470);
            }
        });

        //Disconnect
        allServerMusic.delButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            flagDsAt = true;
            }
        });

        //Добавление строки состояния
        clientState = new JLabel();
        clientState.setText("Change settings...");
        clientState.setBounds(0, 530, 485, 30);
        clientState.setVerticalAlignment(SwingConstants.CENTER);
        clientState.setHorizontalAlignment(SwingConstants.CENTER);
        clientFrame.add(clientState);
    }

    //Интерфейс для показа / сокрытия окна
    //true - показать окно / false - скрыть окно
    public void ViewServerWindow(Boolean viewMode)
    {
        clientFrame.setVisible(viewMode);
    }

    //Интерфейс для изменения строки состояния клиента
    //Новая строка состояния
    public void SetStringState(String enterState)
    {
        clientState.setText(enterState);
    }

    //Функция обновления списка видео
    //Необходимо занести в цикл для корректной работы
    //Обновляемый контейнер
    //Путь папки, в которой ищем файл
    //Имя файла
    public void UpdateMusicList(SContainer enterContainer, String enterFolderPath, String fileName)
    {
        Boolean control = false;

        //Убираем все элементы из списка в контейнере
        enterContainer.RemoveAllElements();

        try
        {
            File file = new File(enterFolderPath + "/" + fileName);
            FileReader reader = new FileReader(file);
            BufferedReader bufferedReader = new BufferedReader(reader);

            String readLine = bufferedReader.readLine();

            while(readLine != null)
            {
                enterContainer.AddNewElement(readLine);
                readLine = bufferedReader.readLine();
                control = true;
            }

            //Елси нет элементов в списке
            if(control == false)
            {
                enterContainer.AddNewElement("No Music!");
            }

        }
        catch(FileNotFoundException fe)
        {
            System.out.println(fe);
            return;
        }
        catch(IOException IOE)
        {
            System.out.println(IOE);
            return;
        }
    }
}